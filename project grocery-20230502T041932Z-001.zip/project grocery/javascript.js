function btn()
{
    // alert("Login successful");
    document.getElementById('frm1').submit();
}


function sltitm()
{
    // =document.getElementById("stditm");
    // var obj= document.getElementById("stditm").obj.options[obj.selectedindex].text;
    // if(document.getElementById("stditm").value==RICE)
    // {
    //     document.getElementById('RICE').style.display='none';
    //     document.getElementById('DAL').style.display='block';

    // }
    // else if (document.getElementById("stditm").value==DAL)
    // {
    //     document.getElementById('DAL').style.display='none';
    //     document.getElementById('RICE').style.display='block';
    // }

    var obj=document.getElementById("sltitm");
    document.getElementById("demo").innerHTML=obj.options[obj.selectedindex].text;  
}